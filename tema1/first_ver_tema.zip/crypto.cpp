#include<bits/stdc++.h>


using namespace std;
ifstream fin("crypto.in");
ofstream fout("crypto.out");
vector<pair<int, int>> v;

int ok(int cnt, int budget) {
	unsigned long long int need = 0;
	for(int i = 0; i < v.size(); i++) {
		if(v[i].first >= cnt)
			break;
		need = need + (cnt-v[i].first)*v[i].second;
		if(need > budget)
			return 0;
	}
	return need <= budget;
}


int main() {
	ios_base::sync_with_stdio(false);
	unsigned long long int n, b, p, u;
	fin >> n >> b;
	unsigned long long int mx = 0;
	for(int i = 0; i < n; i++) {
		fin >> p >> u;
		mx = fmax(mx, p);
		v.push_back({p, u});
	}
	sort(v.begin(), v.end());
	unsigned long long int l = 0;
	unsigned long long int r = b;
	unsigned long long int res = -1;
	unsigned long long int m = -1;
	while(l <= r) {
		m = l + (r - l)/2;
		if(ok(m, b)) {
			res = m;
			l = m + 1;
		} else {
			r = m - 1;
		}
	}
	fout << res;

	return 0;
}
