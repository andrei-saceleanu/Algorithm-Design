#include<bits/stdc++.h>

using namespace std;

ifstream fin("poduri.in");
ofstream fout("poduri.out");
int n, m, x, y, cx, cy, nx, ny;

int inside(int a, int b) {
	return (a >= 0) && (a < n) && (b >= 0) && (b < m);
}



int main() {
	fin >> n >> m;
	fin >> x >> y;
	vector<string> mat;
	fin.get();
	for(int i = 0; i < n; i++) {
		string s;
		getline(fin, s);
		mat.push_back(s);
	}
	queue<pair<int, int>> q;
	int **visited = new int*[n];
	int **dist = new int*[n];
	for(int i = 0; i < n; i++) {
		visited[i] = new int[m];
		dist[i] = new int[m];
		for(int j = 0; j < m; j++) {
			visited[i][j] = 0;
			dist[i][j] = INT_MAX;
		}
	}
	int sx = x-1, sy = y-1;
	int dx[] = {-1, 0, 1, 0};
	int dy[] = {0, 1, 0, -1};
	dist[sx][sy] = 0;
	visited[sx][sy] = 1;
	q.push({sx, sy});
	int res = INT_MAX;
	while(!q.empty()) {
		pair<int, int> curr = q.front();
		q.pop();
		cx = curr.first;
		cy = curr.second;

		if(mat[cx][cy] == 'V') {
			if(cx == 0 || cx == n-1) {
				res = fmin(res, 1 + dist[cx][cy]);
			}
			if(inside(cx-1, cy) && !visited[cx-1][cy]) {
				q.push({cx-1, cy});
				dist[cx-1][cy] = dist[cx][cy]+1;
				visited[cx-1][cy] = 1;
			}
			if(inside(cx+1, cy) && !visited[cx+1][cy]) {
				q.push({cx+1, cy});
				dist[cx+1][cy] = dist[cx][cy]+1;
				visited[cx+1][cy] = 1;
			}
		} else if (mat[cx][cy] == 'O') {
			if(cy == 0 || cy == m-1) {
				res = fmin(res, 1 + dist[cx][cy]);
			}
			if(inside(cx, cy-1) && !visited[cx][cy-1]) {
				q.push({cx, cy-1});
				dist[cx][cy-1] = dist[cx][cy]+1;
				visited[cx][cy-1] = 1;
			}
			if(inside(cx, cy+1) && !visited[cx][cy+1]) {
				q.push({cx, cy+1});
				dist[cx][cy+1] = dist[cx][cy]+1;
				visited[cx][cy+1] = 1;
			}
		} else if (mat[cx][cy] == 'D') {
			if(cx == 0 || cx == n-1 || cy == 0 || cy == m-1) {
				res = fmin(res, 1 + dist[cx][cy]);
			}
			for(int k = 0; k < 4; k++) {
				nx = cx + dx[k];
				ny = cy + dy[k];
				if(inside(nx, ny) && !visited[nx][ny]) {
					q.push({nx, ny});
					dist[nx][ny] = dist[cx][cy]+1;
					visited[nx][ny] = 1;
				}
			}
		}
	}
	if(res == INT_MAX) {
		fout << -1;
	} else {
		fout << res;
	}
	return 0;
}
