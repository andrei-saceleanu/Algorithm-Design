#include<bits/stdc++.h>

using namespace std;

ifstream fin("lego.in");
ofstream fout("lego.out");
int k, n, t, s;
int *used;
vector<int> sol, coeffs, res;
vector<vector<int>> c;
int max_len;
int increasing(int p) {
	if(p >= 1) {
		return sol[p] > sol[p-1];
	}
	return 1;
}


void bkt2() {
	for(int i = 0; i <= t; i++) {
		coeffs.push_back(i);
		s += i;
		if(s <= t && coeffs.size() <= n) {
			if(s <= t && s > 0 && coeffs.size() == n) {
				c.push_back(coeffs);
			} else {
				bkt2();
			}
		}
		s -= i;
		coeffs.pop_back();
	}
}

void check() {
	int x;
	int *nums = (int *)calloc(t * k + 1, sizeof(int));
	for(int i = 0; i < c.size(); i++) {
		x = 0;
		for(int j = 0; j < n; j++) {
			x += sol[j] * c[i][j];
		}
		nums[x] = 1;
	}
	int mx_len = 0, len;
	int i = 1;
	while(i <= t * k) {
		if(nums[i] == 0) {
			i++;
		} else {
			len = 0;
			while(i <= t * k && nums[i] == 1) {
				len++;
				i++;
			}
			mx_len = fmax(mx_len, len);
		}
	}
	if(mx_len > max_len) {
		max_len = mx_len;
		res = sol;
	}
}


void bkt(int p) {
	for(int i = 2; i <= k; i++) {
		if(!used[i]) {
			sol.push_back(i);
			used[i] = 1;
			if(increasing(p)) {
				if(p == n-1) {
					check();
				} else {
					bkt(p + 1);
				}
			}
			used[i] = 0;
			sol.pop_back();
		}
	}
}

int main() {
	fin >> k >> n >> t;
	sol.push_back(1);
	used = (int *)calloc(k + 1, sizeof(int));
	used[1] = 1;
	bkt2();
	bkt(1);
	fout << max_len << "\n";
	for(int i = 0; i < res.size(); i++) {
		fout << res[i] << " ";
	}
	return 0;
}
